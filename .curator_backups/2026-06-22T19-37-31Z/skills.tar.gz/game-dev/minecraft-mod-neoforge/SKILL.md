---
name: minecraft-mod-neoforge
description: NeoForge 1.21.x mod project setup, build quirks, datapack/recipe formats, and procedural texture generation with Pillow. Use when scaffolding or iterating on a NeoForge mod.
triggers:
  - NeoForge mod setup
  - Minecraft mod scaffold
  - build.gradle neoforge
  - Minecraft recipe JSON format
  - procedural Minecraft textures
  - ModDevGradle
---

# Minecraft NeoForge Mod Development

Use this when scaffolding, building, or debugging a NeoForge 1.21.x Minecraft mod.

## JDK requirement

Minecraft 1.21.x requires JDK 21. If `java` is not installed:

```bash
# via tarball (no sudo needed):
curl -sL "https://api.adoptium.net/v3/assets/latest/21/hotspot?os=linux&architecture=x64&image_type=jdk" \
  -o /tmp/jdk_info.json
# Extract binary.package.link from JSON, download .tar.gz
mkdir -p ~/.local/java && tar xzf /tmp/jdk21.tar.gz -C ~/.local/java
export JAVA_HOME=~/.local/java/jdk-21.0.11+10   # or whatever version
export PATH="$JAVA_HOME/bin:$PATH"
```

Persist in `~/.bashrc`:
```bash
export JAVA_HOME="$HOME/.local/java/jdk-21.0.11+10"
export PATH="$JAVA_HOME/bin:$PATH"
```

## Project scaffold

### settings.gradle
```groovy
pluginManagement {
    repositories {
        mavenLocal()
        gradlePluginPortal()
        maven { url = 'https://maven.neoforged.net/releases' }
    }
}
plugins {
    id 'org.gradle.toolchains.foojay-resolver-convention' version '0.9.0'
}
```

### build.gradle (key sections)
```groovy
plugins {
    id 'java-library'
    id 'net.neoforged.moddev' version '2.0.141'  // check Maven for latest
}

neoForge {
    version = neo_version  // e.g. "21.1.234" — check Maven for latest
    runs {
        client { client() }
        server { server(); programArgument '--nogui' }
        gameTestServer { type = "gameTestServer" }
        data { data(); /* datagen args */ }
    }
    mods { "${mod_id}" { sourceSet sourceSets.main } }
}
```

### Known build quirks

1. **`${mod_version}` not expanded in `neoforge.mods.toml`** — `processResources` must expand properties:
   ```groovy
   tasks.withType(ProcessResources).configureEach {
       var replaceProperties = [
           minecraft_version: minecraft_version,
           neo_version: neo_version,
           mod_id: mod_id,
           mod_version: mod_version,
       ]
       inputs.properties replaceProperties
       filesMatching(['META-INF/neoforge.mods.toml']) { expand replaceProperties }
   }
   ```

2. **Dev runs can't find `META-INF/neoforge.mods.toml`** — ModDevGradle puts resources in `build/resources/main/` but NeoForge's classpath scanner looks in `build/classes/java/main/`. Workaround:
   ```groovy
   tasks.named('classes') {
       doLast {
           copy {
               from layout.buildDirectory.dir('resources/main/META-INF')
               into layout.buildDirectory.dir('classes/java/main/META-INF')
           }
       }
   }
   tasks.named('jar') { duplicatesStrategy = DuplicatesStrategy.EXCLUDE }
   ```

3. **Recipes: key values must be objects in 1.21.x**, not plain strings:
   ```json
   // WRONG (old format):
   "key": {"S": "thau:orda_shard"}
   // RIGHT (1.21.x):
   "key": {"S": {"item": "thau:orda_shard"}}
   ```

4. **Worldgen: placed_feature `count` and `height` use nested objects**:
   ```json
   {
     "count": {"type": "minecraft:uniform", "min_inclusive": 1, "max_inclusive": 3},
     "height": {
       "type": "minecraft:uniform",
       "min_inclusive": {"absolute": -64},
       "max_inclusive": {"absolute": 16}
     }
   }
   ```

5. **Custom datapack registries** use `NewRegistryEvent` + `RegisterEvent`:
   ```java
   // Step 1: Create the registry in NewRegistryEvent (MOD bus)
   @SubscribeEvent
   static void registerRegistry(NewRegistryEvent event) {
       event.register(new RegistryBuilder<>(ASPECT_REGISTRY_KEY).sync(true).create());
   }

   // Step 2: Register entries in RegisterEvent (MOD bus) — CODE, not JSON!
   // WARNING: NeoForge 1.21.x custom registries do NOT support datapack JSON loading.
   // The \"data/<ns>/<registry_path>/<name>.json\" pattern is for vanilla registries only.
   // Custom registry entries MUST be registered in code via RegisterEvent.
   @SubscribeEvent
   static void registerEntries(RegisterEvent event) {
       event.register(ASPECT_REGISTRY_KEY, helper -> {
           helper.register(ResourceKey.create(ASPECT_REGISTRY_KEY, ResourceLocation.fromNamespaceAndPath(\"modid\", \"entry_name\")),
               new MyEntry(...));
       });
   }
   ```
   **Pitfall**: trying to load custom registry entries from datapack JSON (`data/<ns>/<registry_path>/<name>.json`) will silently fail and mark the mod's datapack as \"incompatible\". The server may still start but entries won't be registered.
   
   **Diagnosis**: if you see `mod/<modid> (incompatible)` in the crash report's data pack list, check whether you put custom registry entries in datapack JSONs. The incompatibility warning is often from malformed datapack entries, not from recipe/loot table errors.
   
   **Fix**: move all custom registry entries to `RegisterEvent` listeners in code. Only vanilla registries (biomes, configured features, placed features, etc.) and NeoForge data maps support datapack JSON loading.

6. **Loot tables: don't use `minecraft:alternatives` without conditions** — use flat weighted entries instead.

7. **EULA**: dev servers need `eula=true` in `run/server/eula.txt` and `online-mode=false` in `server.properties`.

## Block/entity registration pitfalls

### `BaseEntityBlock` requires `codec()` override
**Symptom**: `YourBlock is not abstract and does not override abstract method codec() in BaseEntityBlock`
**Cause**: NeoForge 1.21.x added an abstract `codec()` to `BaseEntityBlock`.
**Fix**: Add a `MapCodec` field and override method. The constructor must also take `BlockBehaviour.Properties`:
```java
public class MyBlock extends BaseEntityBlock {
    public static final MapCodec<MyBlock> CODEC = simpleCodec(MyBlock::new);

    public MyBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }

    @Override
    protected MapCodec<MyBlock> codec() { return CODEC; }
}
```
**Pitfall**: `simpleCodec(MyBlock::new)` requires a constructor that takes `BlockBehaviour.Properties`. A no-arg constructor will fail with "incompatible types: invalid constructor reference".

### `CraftingTableBlock` subclass cannot override `codec()`
**Symptom**: `codec() in MyBlock cannot override codec() in CraftingTableBlock`
**Cause**: `CraftingTableBlock.codec()` returns `MapCodec<CraftingTableBlock>`, and the subclass can't return a covariant `MapCodec<MyBlock>` because `MapCodec` is invariant.
**Fix**: Don't override `codec()` at all. The parent's codec handles serialization correctly. Your subclass just needs the constructor:
```java
public class MyBlock extends CraftingTableBlock {
    public MyBlock(BlockBehaviour.Properties properties) { super(properties); }
}
```

### `FenceGateBlock` — illegal forward reference to `WoodType`
**Symptom**: `illegal forward reference` at the line registering a `FenceGateBlock`.
**Cause**: The `WoodType` field is declared AFTER the block registration that references it in a supplier lambda. Java's static initializer order matters here — the lambda captures the field reference at class init time.
**Fix**: Move the `WoodType` declaration above all block registrations that reference it:
```java
// MUST come before FenceGateBlock registration
public static final WoodType MY_WOOD = WoodType.register(
    new WoodType("modid:mywood", BlockSetType.OAK));

public static final Supplier<Block> MY_FENCE_GATE = registerBlockAndItem("my_fence_gate",
    () -> new FenceGateBlock(MY_WOOD, BlockBehaviour.Properties.ofFullCopy(PLANKS.get())));
```

### `TreeGrower` takes `ResourceKey<ConfiguredFeature>`, not `ResourceLocation`
**Symptom**: `incompatible types: inference variable T has incompatible bounds` when constructing `TreeGrower`.
**Cause**: The `Optional` parameters of `TreeGrower` expect `Optional<ResourceKey<ConfiguredFeature<?, ?>>>`, not `Optional<ResourceLocation>`.
**Fix**: Use `ResourceKey.create()`:
```java
private static final ResourceKey<ConfiguredFeature<?, ?>> MY_TREE =
    ResourceKey.create(Registries.CONFIGURED_FEATURE,
        ResourceLocation.fromNamespaceAndPath(MODID, "my_tree"));

public static final TreeGrower INSTANCE = new TreeGrower(
    "my_tree", Optional.empty(), Optional.of(MY_TREE), Optional.empty());
```

### Configured feature JSON: avoid `fancy_foliage_placer` with `IntProvider` radius
**Symptom**: `Failed to parse configured_feature JSON` with `Not a number: {"type":"minecraft:uniform",...}`
**Cause**: In 1.21.x, `fancy_foliage_placer`'s `radius` field changed to a plain `int`, not an `IntProvider`. Using `{"type":"minecraft:uniform",...}` for radius fails.
**Fix**: For fancy tree variants, use `blob_foliage_placer` with same dimensions instead, or verify the exact field type for the version. `blob_foliage_placer` is the most reliable choice:
```json
"foliage_placer": { "type": "minecraft:blob_foliage_placer", "radius": 3, "offset": 0, "height": 4 }
```

## Port conflicts when running dev server alongside production

When the user runs a production Minecraft server on the default port (25565), the NeoForge dev server (`./gradlew runServer`) will crash with `bind(..) failed: Address already in use`.

**Do NOT kill the production server.** Instead, create a custom `server.properties` in the `run/` directory:
```bash
mkdir -p run
cat > run/server.properties << 'EOF'
server-port=25599
level-name=dev
online-mode=false
max-players=2
EOF
```
The dev server will use this file automatically on the next `runServer`.

## Custom network packets (1.21.x)

```java
public record MyPacket(int data) implements CustomPacketPayload {
    public static final Type<MyPacket> TYPE = new Type<>(ResourceLocation.fromNamespaceAndPath("modid", "my_packet"));
    public static final StreamCodec<RegistryFriendlyByteBuf, MyPacket> STREAM_CODEC = /* ... */;

    @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }
    public static void handle(MyPacket pkt, IPayloadContext ctx) { ctx.enqueueWork(() -> { /* client work */ }); }
}

// Register in a MOD bus subscriber:
@SubscribeEvent
public static void register(RegisterPayloadHandlersEvent event) {
    event.registrar("modid").playToClient(MyPacket.TYPE, MyPacket.STREAM_CODEC, MyPacket::handle);
}
```

## Procedural textures with Pillow

For Minecraft 16×16 pixel art, Pillow scripts are often more practical than AI generation. See `references/procedural-minecraft-textures.md` for the pattern.

## Extracting textures from old mod JARs

When porting or taking inspiration from classic mods, extract textures directly from the old JAR using Python's `zipfile` module. Remap the namespace and rename plural directories (`blocks/` → `block/`, `items/` → `item/`) to modern conventions. See `references/texture-extraction.md` for the full pattern.

## References

- `references/texture-extraction.md` — Extracting and remapping textures from old mod JARs with Python zipfile.
- `references/procedural-minecraft-textures.md` — Pillow texture generation patterns for ingots, crystals, shards, blocks, and tree items.
