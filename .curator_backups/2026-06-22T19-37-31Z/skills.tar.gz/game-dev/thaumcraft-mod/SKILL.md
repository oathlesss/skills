---
name: thaumcraft-mod
description: >
  Build the Thaumcraft recreation mod (NeoForge 1.21.1). Project structure, TC6-derived
  patterns, recipe format pitfalls, aura system architecture, and testing workflow.
  Load when working on /home/ruben/thaumcraft — any code change, build, or system
  implementation.
---

# Thaumcraft Mod — Development Skill

**Project**: `/home/ruben/thaumcraft` | **Mod ID**: `thau` | **MC**: 1.21.1 NeoForge 21.1.234
**Java**: JDK 21 at `/home/ruben/.local/java/jdk-21.0.11+10`

## Triggers

Load this skill for any work in `/home/ruben/thaumcraft/` — feature implementation, bug
fixes, builds, server tests, recipe authoring, or architecture decisions.

## Critical Pitfalls

### Recipe ingredient format (NeoForge 1.21.1)

**String shorthand does NOT work for any item in recipe JSON.** Must always use object
format `{"item": "namespace:id"}` — even for vanilla items. The shorthand `"minecraft:iron_ingot"`
causes `JsonParseException: "Not a json array: ...; Not a JSON object: ..."`. This is
different from vanilla 1.21 behavior.

```json
// ❌ BREAKS:
"key": { "I": "minecraft:iron_ingot" }

// ✓ CORRECT:
"key": { "I": { "item": "minecraft:iron_ingot" } }
```

Run `python3 -c "..."` (see `references/recipe-fixer.py`) to batch-fix all recipes.

### EventBusSubscriber.Bus.MOD is deprecated in NeoForge 21.1.234

The `@EventBusSubscriber(modid = ..., bus = EventBusSubscriber.Bus.MOD)` annotation
produces removal warnings. This is cosmetic — the code still works — but new files
should use the default bus (which is `MOD`) or omit the `bus` parameter entirely.

### ItemInteractionResult.PASS does not exist

In MC 1.21.1, use `ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION` instead.

### RandomSource vs Random

`ServerLevel.getRandom()` returns `RandomSource`, which is compatible with most Minecraft
APIs but NOT with `Collections.shuffle(List, Random)` or `java.util.Random`. Use inline
iteration when the order doesn't matter, or copy values into a `java.util.Random` if
full shuffle is needed.

## Architecture Patterns

### Per-chunk data: AttachmentType on LevelChunk

```java
public static final Supplier<AttachmentType<AuraAttachment>> AURA =
    ATTACHMENT_TYPES.register("aura",
        () -> AttachmentType.builder(AuraAttachment::new)
                .serialize(AuraAttachment.CODEC).build());
// Usage:
LevelChunk chunk = level.getChunkSource().getChunkNow(x, z);
AuraAttachment aura = chunk.getData(AURA.get());
```

For per-player data, attach to `Player` instead.

### Custom recipe type

1. Recipe class implementing `Recipe<SingleRecipeInput>` with custom `matches()`
2. Static `Serializer` inner class with `MapCodec` and `StreamCodec`
3. `ThauRecipes` registry: `DeferredRegister<RecipeType<?>>` + `DeferredRegister<RecipeSerializer<?>>`
4. Register both in `Thaumcraft` constructor
5. JSON recipe lookup: `level.getRecipeManager().getAllRecipesFor(ThauRecipes.CRUCIBLE_TYPE.get())`

### Block entities with tickers

```java
public class MyBlock extends BaseEntityBlock {
    @Override public BlockEntity newBlockEntity(BlockPos pos, BlockState state) { ... }
    @Override public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level l, BlockState s, BlockEntityType<T> t) {
        return l.isClientSide() ? null :
            createTickerHelper(t, ThauBlocks.MY_ENTITY.get(), MyBlockEntity::tick);
    }
}
```

### Network packet pattern

```java
public record MyPacket(...) implements CustomPacketPayload {
    public static final Type<MyPacket> TYPE = new Type<>(ResourceLocation...);
    public static final StreamCodec<ByteBuf, MyPacket> STREAM_CODEC = StreamCodec.composite(...);
    @Override public Type<?> type() { return TYPE; }
    public static void handle(MyPacket packet, IPayloadContext ctx) {
        ctx.enqueueWork(() -> { /* process */ });
    }
}
// Register: registrar.playToClient(MyPacket.TYPE, MyPacket.STREAM_CODEC, MyPacket::handle);
```

## Aura System (TC6-derived)

- **Single vis/flux floats per chunk** (not per-aspect arrays) — matching TC6
- **Base** (short): set at chunk generation from biome tag averaging + Gaussian noise
- **Regen**: vis+flux < base → add phaseVis. vis > 125% base → convert to flux
- **Neighbor balancing**: vis/flux flows from high to low neighbors
- **Moon phase**: modulates regen rates via PHASE_VIS/PHASE_MAX tables
- **Flux saturation > 75%**: rift trigger (Phase 7)
- See `references/tc6-aura-algorithm.md` for the full TC6 comparison

## Build & Test Commands

```bash
cd /home/ruben/thaumcraft
export JAVA_HOME=/home/ruben/.local/java/jdk-21.0.11+10
./gradlew build                    # compile + jar
timeout 35 ./gradlew runServer     # headless server test (check for "Done" + no errors)
```

Server loads clean in ~2 seconds with zero errors on a successful build.

## File Layout

```
src/main/java/com/thau/
  lib/           API surface — aspects, datamap, mod compat events
  core/          Implementation
    aura/        AuraAttachment, AuraManager, AuraSyncPacket, ClientAuraData, AuraHudOverlay
    block/       Block classes + ThauBlocks (registrations)
    block/entity/ CrucibleBlockEntity, InfusionAltarBlockEntity, EssentiaJarBlockEntity
    client/      ThaumonomiconScreen
    item/        ThauItems (registrations + creative tab), ThaumometerItem, ThaumonomiconItem
    recipe/      CrucibleRecipe, ThauRecipes (recipe type/serializer registry)
    research/    ResearchAttachment, ResearchManager, ResearchSyncPacket
    worldgen/    Tree features, placed features, biome modifiers
  Thaumcraft.java   Main mod class (registrations)
  ThauNetwork.java  Payload handler registration
```

## Related Files

- Plan: `/home/ruben/thaumcraft-remake-plan.md`
- Test plan: `/home/ruben/thaumcraft-test-plan.md`
- TC6 review: `/home/ruben/thaumcraft-tc6-review.md`
- TC6 reference source: `/home/ruben/thaumcraft-reference-tc6-source/`
- TC4 reference jar: `/home/ruben/thaumcraft-reference/Thaumcraft-1.7.10-4.2.3.5.jar`
