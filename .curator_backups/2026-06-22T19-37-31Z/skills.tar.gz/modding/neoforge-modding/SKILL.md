---
name: neoforge-modding
description: >
  Build Minecraft mods for NeoForge 1.21.x. Covers project scaffolding,
  registry patterns (blocks/items/entities/attachments/recipes), data-driven
  JSON recipes/datamaps, block entities with tickers, custom recipe types,
  network packets, and common 1.21.1 pitfalls. Use when the user asks to
  create, extend, or fix a NeoForge Minecraft mod.
---

# NeoForge 1.21.x Mod Development

## Project Scaffolding

```
build.gradle    — ModDevGradle 2.0.x, NeoForge dependency
settings.gradle — repository + plugin management
gradle.properties — mod_id, mod_version, minecraft_version
src/main/java/com/<modid>/core/ — main mod class
src/main/resources/ — assets, data, META-INF
```

Build: `./gradlew build` | Server test: `./gradlew runServer`

## Registration Patterns

All registrations use `DeferredRegister` registered on the mod event bus:

```java
public static final DeferredRegister<Block> BLOCKS =
    DeferredRegister.create(Registries.BLOCK, MOD_ID);
public static final DeferredRegister<Item> BLOCK_ITEMS = // separate
public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = // separate

// In main mod constructor:
BLOCKS.register(modEventBus);
BLOCK_ITEMS.register(modEventBus);
BLOCK_ENTITIES.register(modEventBus);
```

**Block + Item pattern**: Register both block and its BlockItem in one call, cache the item supplier for creative tabs:
```java
private static Supplier<Block> registerBlockAndItem(String name, Supplier<Block> block) {
    Supplier<Block> b = BLOCKS.register(name, block);
    Supplier<Item> bi = BLOCK_ITEMS.register(name,
        () -> new BlockItem(b.get(), new Item.Properties()));
    blockItemMap.put(name, bi);
    return b;
}
```

**AttachmentType** (per-chunk, per-player state):
```java
public static final Supplier<AttachmentType<MyAttachment>> MY_ATTACH =
    ATTACHMENT_TYPES.register("name",
        () -> AttachmentType.builder(MyAttachment::new)
            .serialize(MyAttachment.CODEC).build());
// Use: chunk.getData(MY_ATTACH.get())
```

**Entity types**:
```java
public static final Supplier<EntityType<MyEntity>> MY_ENTITY =
    ENTITIES.register("name", () -> EntityType.Builder.of(MyEntity::new, MobCategory.MISC)
        .sized(0.6f, 0.8f).clientTrackingRange(8).build("modid:name"));
```

## Recipe System

**Custom recipe type + serializer**:
```java
public static final DeferredRegister<RecipeType<?>> RECIPE_TYPES = ...
public static final DeferredRegister<RecipeSerializer<?>> RECIPE_SERIALIZERS = ...

// Type:
public static final Supplier<RecipeType<MyRecipe>> MY_TYPE =
    RECIPE_TYPES.register("name", () -> RecipeType.simple(...));

// Serializer registered separately, referenced in recipe class
```

**Recipe JSON format** — ingredients MUST use object format in NeoForge 1.21.1:
```json
{
  "type": "modid:recipe_type",
  "key": {
    "S": { "item": "modid:item_name" }
  }
}
```
Do NOT use shorthand `"S": "modid:item"` — this breaks for all items (even vanilla) in this NeoForge version.

## Block Entities

Extend `BaseEntityBlock`, override `newBlockEntity()`, `getTicker()`:
```java
public class MyBlock extends BaseEntityBlock {
    @Override public BlockEntity newBlockEntity(BlockPos pos, BlockState state) { ... }
    @Nullable @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return level.isClientSide() ? null :
            createTickerHelper(type, MY_BE_TYPE.get(), MyBlockEntity::tick);
    }
}
```

## Common Pitfalls

### Recipe JSON: ingredient format
❌ `"S": "minecraft:stick"` — fails with "Not a json array / Not a JSON object"
✅ `"S": { "item": "minecraft:stick" }` — correct for NeoForge 1.21.1

### ItemInteractionResult
`ItemInteractionResult` has NO `PASS` constant. Use:
`ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION`

### Networking: ByteBuf vs FriendlyByteBuf
When writing custom `StreamCodec.of(...)`, the encode/decode methods receive `ByteBuf`, but `readVarInt()`/`writeVarInt()` are on `FriendlyByteBuf`. Either cast `(FriendlyByteBuf) buf` or declare parameters as `FriendlyByteBuf`.

### @OnlyIn(Dist.CLIENT) on network handlers
`@OnlyIn(Dist.CLIENT)` on a packet handler method causes `NoSuchMethodError` on dedicated servers because the annotation strips the method. Remove the annotation — the handler only fires on client anyway since it's registered with `playToClient`.

### ChunkEvent.Load → LevelChunk
`ChunkEvent.Load.getChunk()` returns `ChunkAccess`, not `LevelChunk`. Cast:
```java
if (!(event.getChunk() instanceof LevelChunk chunk)) return;
```

### Collections.shuffle with RandomSource
`Collections.shuffle(List, RandomSource)` doesn't compile — `RandomSource` doesn't extend `Random`. Skip the shuffle or use a different approach.

### SmallFireball constructor (1.21.1)
No `(Level, LivingEntity, double, double, double)` constructor.
Use `(EntityType, Level)` then `setPos()` + `setDeltaMovement()`.

### Entity base class for AI
If entity uses `FloatGoal`, `HurtByTargetGoal`, or any pathfinding goal, extend `PathfinderMob` not `Mob`. Use `createLivingAttributes()` instead of `Mob.createMobAttributes()`.

### EventBusSubscriber.Bus.MOD deprecation
`@EventBusSubscriber(modid = ..., bus = EventBusSubscriber.Bus.MOD)` emits deprecation warnings in NeoForge 21.1.234+. The `bus` parameter is being removed. These are warnings only — code still works.

## Data-Driven Systems

**Aspect/item datamap**:
```java
public static final DataMapType<Item, List<AspectStack>> ITEM_ASPECTS =
    DataMapType.builder(ResourceLocation.fromNamespaceAndPath("modid", "item_aspects"),
        Registries.ITEM, AspectStack.LIST_CODEC).build();
```
JSON files go in `data/<ns>/datamap/item_aspects/`.

**Research entries**: Hardcode in a `ResearchManager` static initializer, with JSON loading as an extension path. JSON format uses `key`, `name`, `category`, `stages[]`, `parents[]`, `siblings[]`, `meta[]`, `reward_knowledge[]`.

**Dimension datapack**: `data/<ns>/dimension/<name>.json` + `data/<ns>/dimension_type/<name>.json`.

## Verification

After every subsystem change:
```bash
./gradlew build          # must pass
timeout 35 ./gradlew runServer 2>&1 | grep "(Done|ERROR)"  # must show Done, no errors
```

Commit after each working subsystem — commits are cheap, debugging broken state is expensive.

## Reference Files

- `references/tc6-aura-patterns.md` — TC6 aura system mechanics (biome generation, neighbor balancing, moon phases, biome multipliers) with 1.21.1 porting notes
- `templates/recipe-shaped.json` — correct NeoForge 1.21.1 shaped recipe JSON template (object ingredient format)
